Thu Dec  8 02:42:58 EST 2016

I don't want to type a license out, so:
You can use this program privately or commercially.
You can modify this program.
You can distribute the program in its original or modified form, for whatever purpose.
You can't hold the creators liable for damages

^ If you're worried read the source, it's not that long.

Build Instructions:
	# this file should be in your working directory,
	# and jdk1.8.0_xx\bin should be in $PATH or %PATH%

	javac -d Server ChatServer.java
	javac -d Client ChatClient.java
	
	# create file .\Server\META-INF\MANIFEST.MF, with this content:
	#	Manifest-Version: 1.0
	#	Main-Class: ChatServer
	#	
	#

	# create file .\Client\META-INF\MANIFEST.MF, with this content:
	#	Manifest-Version: 1.0
	#	Main-Class: ChatClient
	#	
	#

	jar cvfmM sunjce_provider.jar .\Server\manifest.mf -C .\Server .
	jar cvfmM charsets.jar .\Client\manifest.mf -C .\Client .	



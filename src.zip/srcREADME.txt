Sat Dec 24 12:58:43 EST 2016

I don't want to type a license out, so:
You can use this program privately or commercially.
You can modify this program.
You can distribute the program in its original or modified form, for whatever purpose.
You can't hold the creators liable for damages

^ If you're worried read the source, it's not that long.
^ Sorry for not using comments

Build Instructions:
	This file should be in your working directory,
	Your JDK 7 or 8 bin directory should be in $PATH or %PATH%
		This can be tested with the command java -version.
		If it doesn't work, make sure your PATH variable is correct:
		
		Linux example: $ export PATH=$PATH:/opt/java8/jdk1.8.0_111/bin
		Windows example: > PATH=%PATH%;C:\Program Files (x86)\jdk1.7.0_121\bin

	Then run these commands to build the binaries
	Windows:
		cd ChatServer
		javac ChatServer.java
		cd ..\ChatClient
		javac ChatClient.java
		cd ..
		del /S *.java
		jar cvfmM ChatServer.jar .\ChatServer\META-INF\manifest.mf -C .\ChatServer .
		jar cvfmM ChatClient.jar .\ChatClient\META-INF\manifest.mf -C .\ChatClient .
	
	Linux:
		cd ChatServer
		javac ChatServer.java
		cd ../ChatClient
		javac ChatClient.java
		cd ..
		find -name \*.java -delete
		jar cvfmM ChatServer.jar ./ChatServer/META-INF/manifest.mf -C ./ChatServer .
		jar cvfmM ChatClient.jar ./ChatClient/META-INF/manifest.mf -C ./ChatClient .

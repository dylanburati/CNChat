package ChatUtils;

import java.util.ArrayList;
import java.util.List;

public class CNConversationStore {
    private List<CNConversation> arr = new ArrayList<>();

    public CNConversationStore(String fin) {
        if(fin != null) {
            // todo import conversations
        }
    }
}

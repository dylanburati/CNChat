package ChatUtils;

import java.util.HashMap;

public class CNConversationStore<K, V> extends HashMap {
    private String path;

    public CNConversationStore(String path) {
        this.path = path;
    }

    public void store(K o, V o2) {
        super.put(o, o2);
        ;
    }
}

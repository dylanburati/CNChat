Build Instructions:
	This file should be in your working directory,
	Your JDK 7 or 8 bin directory should be in $PATH or %PATH%
		This can be tested with the command java -version.
		If it doesn't work, make sure your PATH variable is correct:
		
		Linux example: $ export PATH=$PATH:/opt/java8/jdk1.8.0_111/bin
		Windows example: > PATH=%PATH%;C:\Program Files (x86)\jdk1.7.0_121\bin

	Then run these commands to build the binaries
	Windows:
		cd ChatServer
		javac ChatServer.java
		cd ..
		del /S *.java
		jar cvfmM ChatServer.jar .\ChatServer\META-INF\MANIFEST.MF -C ChatServer .

	Mac or Linux:
		cd ChatServer
		javac ChatServer.java
		cd ..
		find -name \*.java -delete
		jar cvfmM ChatServer.jar ./ChatServer/META-INF/MANIFEST.MF -C ChatServer .


Update Instructions:
    These commands will update CNChat if you obtained it with the ``git clone'' command,
    or if you downloaded it as a .zip file from github.com

    Windows, Mac, or Linux:
        git fetch
        git checkout master
        git reset --hard origin/master

    To preserve local changes, such as the configuration file, run ``git stash'' before the
    commands, and ``git stash apply'' after the reset.
